const express = require("express");
const router = express.Router();
const {getBlogStat, blogSearchHandler} = require("../handlers/blogHandler");

router.get("/fetch-blog-data", getBlogStat );
router.get("/blog-search", blogSearchHandler);


module.exports = router;