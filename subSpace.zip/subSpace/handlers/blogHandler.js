// importing lodash
const _ = require("lodash");
// importing util function
const getBlogs = require("../utils/fetchBlogs");

// creating handler for blog stat
exports.getBlogStat = async (req, res) => {
  try {
    // fetching blogs data through utils function
    const response = await getBlogs();
    // applying some validate to handle the case if no data a fetched
    if (!response) {
      return res.status(500).json({
        success: false,
        message: "No Data Recieved",
      });
    }

    // extracting blogs from response
    const blogs = response.data.blogs;

    // finding a specific blog with the longest title
    const blogWithLongestTitle = _.maxBy(blogs, (blog) => blog.title.length);

    //  filtering blogs with titles containing "privacy"
    const blogsWithPrivacyTitle = _.filter(blogs, (blog) =>
      _.includes(_.toLower(blog.title), "privacy")
    );

    //number of blogs with "privacy" in the title
    const numberOfBlogsWithPrivacyTitle = blogsWithPrivacyTitle.length;

    // getting blogs having unique title
    const uniqueBlogTitles = _.uniqBy(blogs, "title");

    // creating an object which will contain all required data
    const statObj = {
      "Total number of blogs": blogs.length,
      "The title of the longest blog": blogWithLongestTitle.title,
      "Number of blogs with 'privacy' in the title":
        numberOfBlogsWithPrivacyTitle,
      "An array of unique blog titles": uniqueBlogTitles,
    };
    // Send the response data back to the requesting body
    return res.status(200).json({
      success: true,
      message: "Blog data fetched successfully.",
      statObj,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      error: "An error occurred while fetching blog data",
    });
  }
};


// creating handler to perform search operations based on input query
exports.blogSearchHandler = async (req, res) => {
  try {
    // getting query parameter
    const { query } = req.query;
    if(!query){
      return res.status(400).json({
        success:false,
        message:"query parameter is must. You can't left it empty"
      })
    }
    console.log("Query Value:", query);

    // fetching all blogs
    const response = await getBlogs();

    // Applying validation to handle  the case if no data is fetched or
    // undefined or null data is received
    if (!response) {
      return res.status(500).json({
        success: true,
        message: "No Data Found.",
      });
    }

    // getting array of blogs with unique title
    const uniqueBlogs = _.uniqBy(response.data.blogs, "title");

    // filtering blogs on the basis of given query
    const requiredBlogs = _.filter(uniqueBlogs, (blog) =>
      _.includes(_.toLower(blog.title), _.toLower(query))
    );
    // returning response
    return res.status(200).json({
      success: true,
      message: "Query Executed successfully",
      requiredBlogs,
    });
  } catch (error) {
    console.log("Error Occured while search for blogs.");
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
