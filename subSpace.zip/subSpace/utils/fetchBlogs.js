require("dotenv").config();
const axios = require("axios");


const getBlogs = async ()=>{
    try{
         const result = await axios.get(
            process.env.BLOG_URL,
            {
              headers: {
                "x-hasura-admin-secret":
                  process.env.HEADER_SECRET,
              },
            }
          );
          // console.log("Printing Result:",result)

          return result;
      
    }catch(error){
        console.log("Error Occured inside fetchBlogs utils function")
        return null;
       
    }
}

module.exports = getBlogs;

