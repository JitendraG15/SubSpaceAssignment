// Importing express  modules
const express = require("express"); 
// Getting all routes
const blogsRoute = require("./routes/blogsRoute")

// Creating an Express application
const app = express();

// Adding json parser middleware
app.use(express.json());

// Mounting routes related to blog statistics
app.use("/api/v1/", blogsRoute);

// port number
const PORT = process.env.PORT || 4000;

// making  server live to listen any  upcoming request
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
